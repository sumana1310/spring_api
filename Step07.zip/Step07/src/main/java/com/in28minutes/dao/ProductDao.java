package com.in28minutes.dao;
import java.util.List;

	import com.in28minutes.model.*;
	
	public interface ProductDao {
		
		public List<Product> getAllProducts();
	}
	
