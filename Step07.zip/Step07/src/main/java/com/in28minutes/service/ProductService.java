package com.in28minutes.service;
import com.in28minutes.model.Product;
import java.util.List;
public interface ProductService {

	public List<Product> getAllProducts();

	/* Product getProductById(String productId); */

	/*
	 * void deleteProduct(String productId);
	 * 
	 * void addProduct(Product product);
	 * 
	 * void editProduct(Product product);
	 */
}