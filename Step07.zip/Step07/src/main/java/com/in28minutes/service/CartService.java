package com.in28minutes.service;

import com.in28minutes.model.Cart;
	public interface CartService {

		Cart getCartByCartId(String CartId);
	}
