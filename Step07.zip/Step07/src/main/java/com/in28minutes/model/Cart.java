package com.in28minutes.model;

public class Cart {

}
